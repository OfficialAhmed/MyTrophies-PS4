This tool reads [.dat] file of the PS4 trophies.
Because HEN exploit users are no longer able to check their trophies level
since it's not connected to PSN, unless you count trophy by trophy 
all by yourself and do the math(you name it...).

So make sure you get the required file from your Console 
either through FTP or PS4 file manager homebrew it's located on:-
[user/home/<your user id>/trophy/data/sce_trop/]

Always the file will be named as [trpsummary.dat] 
copy and paste it within the tool folder [MyTrophies (Beta 0.1)]*inside*

Then Run the tool (As simple as that)

*Do not CHANGE the file name
*Do not CHANGE the tool name
*Do not CHANGE the folder name
otherwise ERRORs will occur

<<<<<<<<<<<<<<<<<< Please Read this carefully >>>>>>>>>>>>>>>>>>>


*if you chose to copy trophies to a text file MAKE SURE you cut & paste the older
 [My Trophies.txt] file
 somewhere else OTHERWISE it'll be overwritten

*In case you want to test my tool I included my trophies .dat file for you to test
 located [...\_1.Read This\.dat file for testing]

Thank you for downloading my tool I hope you like it.

Twitter: @OfficialAhmed0
